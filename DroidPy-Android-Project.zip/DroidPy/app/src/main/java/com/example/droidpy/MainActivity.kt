package com.example.droidpy

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var editor: EditText
    private lateinit var output: TextView
    private lateinit var command: EditText
    private lateinit var status: TextView
    private var currentMode = "python"

    private val bg = Color.rgb(16, 24, 32)
    private val panel = Color.rgb(25, 37, 48)
    private val accent = Color.rgb(85, 214, 190)
    private val textColor = Color.rgb(226, 235, 240)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(bg)
        }

        val header = TextView(this).apply {
            text = "DroidPy   •   Python Workbench"
            textSize = 19f
            setTextColor(accent)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(header)

        status = TextView(this).apply {
            text = "Python 3.13 • Local execution • App sandbox"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(status)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addButton(actions, "Run", accent) { runPython() }
        addButton(actions, "Open", panel) { openDocument() }
        addButton(actions, "Save", panel) { saveDocument() }
        addButton(actions, "Terminal", panel) { toggleTerminal() }
        root.addView(actions)

        editor = EditText(this).apply {
            setText("print('Hello from DroidPy!')\n\nfor i in range(5):\n    print('Count:', i)\n")
            textSize = 14f
            typeface = Typeface.MONOSPACE
            setTextColor(textColor)
            setHintTextColor(Color.GRAY)
            setHint("Write Python code here...")
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(panel)
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(false)
        }
        root.addView(editor, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        command = EditText(this).apply {
            hint = "Shell command (runs as this app, not root)"
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTextColor(textColor)
            setHintTextColor(Color.GRAY)
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(panel)
            visibility = View.GONE
            setSingleLine(true)
        }
        root.addView(command)

        val outputTitle = TextView(this).apply {
            text = "OUTPUT"
            textSize = 11f
            setTextColor(accent)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(9), 0, dp(4))
        }
        root.addView(outputTitle)

        output = TextView(this).apply {
            text = "Ready. Press Run to execute your Python script."
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextColor(textColor)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(panel)
            setTextIsSelectable(true)
            minHeight = dp(105)
        }
        val outScroll = ScrollView(this).apply {
            addView(output)
        }
        root.addView(outScroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(150)
        ))

        setContentView(root)
    }

    private fun addButton(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setTextColor(if (color == accent) bg else textColor)
            setBackgroundColor(color)
            setOnClickListener { action() }
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(4), 0, dp(4), 0)
        }
        parent.addView(button, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
            setMargins(dp(2), 0, dp(2), dp(8))
        })
    }

    private fun runPython() {
        val source = editor.text.toString()
        status.text = "Running Python..."
        worker.execute {
            val result = try {
                Python.getInstance().getModule("runner")
                    .callAttr("run_code", source, filesDir.absolutePath).toString()
            } catch (e: Exception) {
                "Python startup error: ${e.message}"
            }
            runOnUiThread {
                output.text = result
                status.text = "Python 3.13 • Finished"
            }
        }
    }

    private fun toggleTerminal() {
        currentMode = if (currentMode == "python") "shell" else "python"
        command.visibility = if (currentMode == "shell") View.VISIBLE else View.GONE
        if (currentMode == "shell") {
            command.setOnEditorActionListener { _, _, _ ->
                runShell()
                true
            }
            command.requestFocus()
            status.text = "Shell • app UID • working directory: ${filesDir.name}"
        } else {
            status.text = "Python 3.13 • Local execution"
        }
    }

    private fun runShell() {
        val cmd = command.text.toString().trim()
        if (cmd.isEmpty()) return
        command.text.clear()
        worker.execute {
            val result = try {
                val process = ProcessBuilder("/system/bin/sh", "-c", cmd)
                    .directory(filesDir)
                    .redirectErrorStream(true)
                    .start()
                val text = BufferedReader(InputStreamReader(process.inputStream)).use {
                    it.readText()
                }
                val exit = process.waitFor()
                (if (text.isBlank()) "(no output)" else text) + "\n[exit $exit]"
            } catch (e: Exception) {
                "Shell error: ${e.message}"
            }
            runOnUiThread { output.text = result }
        }
    }

    private fun openDocument() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, 1001)
    }

    private fun saveDocument() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/x-python"
            putExtra(Intent.EXTRA_TITLE, "main.py")
        }
        startActivityForResult(intent, 1002)
    }

    @Deprecated("Uses the platform document picker for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri: Uri = data.data!!
        try {
            when (requestCode) {
                1001 -> {
                    contentResolver.openInputStream(uri)?.bufferedReader()?.use {
                        editor.setText(it.readText())
                    }
                    status.text = "File opened"
                }
                1002 -> {
                    contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use {
                        it.write(editor.text.toString())
                    }
                    status.text = "File saved"
                }
            }
        } catch (e: Exception) {
            output.text = "File error: ${e.message}"
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }
}
