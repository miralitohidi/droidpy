import contextlib
import io
import os
import traceback

def run_code(source, work_dir):
    """Execute a script in the app's private working directory and capture output."""
    os.makedirs(work_dir, exist_ok=True)
    os.chdir(work_dir)
    output = io.StringIO()
    scope = {
        "__name__": "__main__",
        "__file__": "<editor>",
        "__builtins__": __builtins__,
    }
    try:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            exec(compile(source, "<editor>", "exec"), scope, scope)
    except BaseException:
        traceback.print_exc(file=output)
    return output.getvalue() or "(no output)"
