# DroidPy — Android Python Workbench

A starter native Android application with an embedded Python 3.13 interpreter.

## Included in this first build

- Embedded Python execution (offline after installation)
- Captured stdout, stderr and Python tracebacks
- Multi-line code editor
- Open and save files using Android's system document picker
- Basic `/system/bin/sh` command runner
- App-private working directory
- Network permission for Python networking libraries

## Important security and Android limitations

This is an ordinary, non-root Android app. The shell runs under the app's Linux UID:
it is **not root**, cannot read arbitrary protected app data, cannot modify system
partitions, and cannot bypass Android's sandbox. The file picker grants access only
to files and folders selected by the user.

The first version is a foundation, not yet a full terminal emulator or package manager.
Python packages with native components must be available as compatible Android wheels
and configured at build time in `app/build.gradle.kts` using Chaquopy's `pip` block.
A normal desktop `pip install` command is not automatically available at runtime.

## Build

1. Install Android Studio with Android SDK Platform 36 and JDK 17.
2. Extract this project.
3. Open the `DroidPy` folder in Android Studio.
4. Allow Gradle to sync and download dependencies.
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Install the generated debug APK on an `arm64-v8a` Android phone.

The Gradle plugin versions are pinned in the project. Gradle wrapper files are not
included; Android Studio can generate/sync the wrapper, or you can run
`gradle wrapper` from a machine with Gradle installed.

## Compatibility

- Minimum Android: 7.0 (API 24)
- Primary phone ABI: arm64-v8a
- Emulator ABI: x86_64
- Embedded Python: 3.13
- compileSdk: 36

## Next development milestones

1. Replace the basic editor with a proper syntax-highlighting editor.
2. Add a persistent project/file explorer rooted in app storage and SAF bookmarks.
3. Add a real terminal session with interactive stdin, command history and cancellation.
4. Add a foreground service for user-visible long-running Python jobs, following Android's
   foreground-service rules and notification requirements.
5. Add a package manager workflow which resolves only compatible Android wheels.
6. Add optional Android API bridges for camera, sensors, Bluetooth and location, each
   behind explicit runtime permissions and user consent.
